<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>LENS Financials </title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta content="Lens Financials" name="description" />
    <meta content="Lens Financials" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- endbuild -->

</head>

<body>

<!-- Begin page -->
<div id="wrapper">

    <?php include ('sidebar.php');?>

    <!-- Page Content Start -->
    <div class="content-page">
        <div class="content">
            <div class="container-fluid">

                <!-- Page title box -->
                <div class="page-title-box">
                    <ol class="breadcrumb float-right">

                        <li class="breadcrumb-item active">Chart of Accounts</li>
                    </ol>
                    <h4 class="page-title">Chart of Accounts</h4>
                </div>
                <!-- End page title box -->



                <!-- end row -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card-box">
                            <h4 class="m-t-0 header-title">Add New Account</h4>


                            <form method="post" action="<?php echo site_url('financial_account/add_chart_of_account_process') ?>" enctype="multipart/form-data" >

                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label class="control-label mb-10 text-left">Account Number: </label>
                                        <input type="number" class="form-control" id="account_number" required name="account_number" placeholder="Account number">
                                        <div class="alert alert-danger" role="alert" id="account_number_alert">

                                        </div>

                                    </div>
                                    <div class="form-group col-md-6">
                                        <label class="control-label mb-10 text-left">Account Name: </label>
                                        <input type="text" class="form-control" required name="account_name" placeholder="Account name">
                                    </div>
                                </div>


                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label class="control-label mb-10 text-left">Type: </label>
                                        <select name="type" id="type" class="form-control custom-select" required>
                                            <option value="0">--Select Type--</option>
                                            <option value="1">Asset</option>
                                            <option value="2">Liability</option>
                                            <option value="3">Capital</option>
                                            <option value="4">Income</option>
                                            <option value="5">Expenses</option>
                                        </select>
                                    </div>

                                    <div class="form-group col-md-6">
                                        <label class="control-label mb-10 text-left">Account Type: </label>
                                        <select name="account_type" id="account_type" class="form-control custom-select" required>
                                            <option value="0">--Select Account Type--</option>
                                            <option value="1">Parent</option>
                                            <option value="2">Detail</option>
                                        </select>
                                    </div>

                                </div>

                                <div class="form-row">

                                    <div class="form-group col-md-6">
                                        <label class="control-label mb-10 text-left">Parent: </label>
                                        <select name="parent" id="parent" class="form-control custom-select">


                                        </select>
                                    </div>
                                    <div class="form-group col-md-6">

                                    </div>

                                </div>

                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" value="1" name="bank" id="customCheck1">
                                            <label class="custom-control-label" for="customCheck1">Bank</label>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <button type="submit" id="add_new_account" class="btn btn-primary btn-block">Add New Account</button>
                                    </div>
                                </div>





                            </form>
                        </div> <!-- end card-box -->
                    </div> <!-- end col -->
                </div>




            </div> <!-- end container-fluid-->
        </div> <!-- end contant-->
    </div>
    <!-- End Page Content-->









    <?php include('footer.php'); ?>




</div>






</body>
</html>