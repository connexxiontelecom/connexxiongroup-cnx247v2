<script>
    $(document).ready(function() {

        $('#account_number_alert').hide();
        $('#add_new_account').prop("disabled", true);
        $("#account_number").blur(function () {
            var account_number = $(this).val();
            account_number = String(account_number);
            var length  = account_number.length;
            if(length%2 == 0){
                $('#account_number_alert').show();
                $('#account_number_alert').html("Length of account number should be odd");
                $('#add_new_account').prop("disabled", true);
            }
            else{
                $('#account_number_alert').hide();
                $('#add_new_account').prop("disabled", false);
            }

        });

        $("#account_type").change(function () {
            var account_type = $(this).val();

            if(account_type == 2){

                var type = $('#type').val();

//                account_number = account_number.toString();
//                account_number = account_number.substring(0, account_number.indexOf(","))

                var dataString = 'type='+type;
                $.ajax({
                    type: 'POST',
                    url: '<?php echo site_url('financial_account/get_parent'); ?>',
                    data: dataString,
                    cache: false,
                    success : function(html){
                        $("#parent").html(html);
                    }
                });

            }


        });



    });

</script>
